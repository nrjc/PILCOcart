set(0,'defaultaxesfontsize',24);
set(0,'defaultaxesfontunits', 'points')
set(0,'defaulttextfontsize',26);
set(0,'defaulttextfontunits','points')
set(0,'defaultaxeslinewidth',1);
set(0,'defaultlinelinewidth',2);
% set(0,'DefaultTextInterpreter','Latex')
set(0,'DefaultAxesLineStyleOrder','-|--|:|-.');
